create view VIEW_STOREALERT as
select g.uuid,g.name,sd.storenum,od.outnum
from goods g,
     (select goodsuuid,sum(num) storenum  from STOREDETAIL  group by goodsuuid) sd,
     (select goodsuuid,sum(num) outnum
             from orderdetail od,orders o
             where od.ordersuuid=o.uuid and  od.state='0' and o.type='2' group by goodsuuid) od
where sd.goodsuuid=g.uuid and od.goodsuuid=g.uuid

